/**
 * 
 */
package modeling.encountergenerator;

/**
 * @author Xueyi
 *
 */
public abstract class EncounterGenerator {

	/**
	 * 
	 */
	public EncounterGenerator() {
		// TODO Auto-generated constructor stub
	}
	
	public void execute()
	{
				
	}
}
