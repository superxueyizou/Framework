/**
 * 
 */
package modeling.subsystems.sensor;

/**
 * @author Xueyi
 *
 */
public abstract class Sensor {

	/**
	 * 
	 */
	protected double range;//
	protected double azimuth; //[-110,110]
	protected double elevation;//[-15,15]
	public Sensor() {
		// TODO Auto-generated constructor stub
	}

}
