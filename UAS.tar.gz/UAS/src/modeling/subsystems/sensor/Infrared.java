/**
 * 
 */
package modeling.subsystems.sensor;

/**
 * @author Xueyi
 *
 */
public class Infrared extends Sensor {

	/**
	 * 
	 */
	public Infrared() {
		// TODO Auto-generated constructor stub
	}

}
