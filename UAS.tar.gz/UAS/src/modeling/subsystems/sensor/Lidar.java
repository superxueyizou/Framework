/**
 * 
 */
package modeling.subsystems.sensor;

/**
 * @author Xueyi
 *
 */
public class Lidar extends Sensor {

	/**
	 * 
	 */
	public Lidar() {
		// TODO Auto-generated constructor stub
	}

}
