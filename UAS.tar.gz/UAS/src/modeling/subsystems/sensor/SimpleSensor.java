/**
 * 
 */
package modeling.subsystems.sensor;

/**
 * @author Xueyi
 *
 */
public class SimpleSensor extends Sensor {

	/**
	 * 
	 */
	public SimpleSensor() {
		// TODO Auto-generated constructor stub
		range= 5;
	}

}
